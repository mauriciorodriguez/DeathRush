"Da Mad Rave", created using High Logic FontCreator by Darrell Flood, is free to use for personal use.
(Tho I still appreciate any donations you might be inclined to give regardless!)

For commercial use, you must donate a minimum of 5$ to me: dadiomouse@gmail.com
(Tho any amounts above this are naturally appreciated even more!)
Please give as much as you honestly feel the font is worth.

Thank-you for downloading this font and I hope you find a use for it!