ONE (1) font by Chris Hansen, all rights reserved 2005

Notes on 1-
This font does not have numbers, except for the 1, for the naming purpose, but instead theres 8 diffrent "dingbats", with f***ed up edges
that can be mixed and used in a variety of ways, so it would look more personal for the user, and not exactly like a font.

CONTACT
Crizcrack_666@hotmail.com
www.geocities.com/Crizcrack666