v.1.2 - 02/10/2005

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
 \\\"D E F U S E D" Truetype Font \\\  Copyright 2005 by reticula.net - Vincent Wicky
  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

  ____________________________________________________________________________________

++The personnal and/or non-commercial uses of this font are FREE. 
  However donations are accepted and appreciated : www.reticula.net ! Thank you for also sending
  me your creations ;) (whatever the support). 

++The professional and/or commercial uses of this font are PROHIBITED unless a small donation is done.
  (see below how to Contact me for details ).

++You are not allowed to distribute these fonts without my permission. Contact me for details.

++You may never ever sell my fonts, include them on CD's or make any changes to the files.

  ___________________________________________________________________________________
  E-mail: contact@reticula.net                           WWW: http://www.reticula.net



v.1.2 - 02/10/2005

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
 \\\"D E F U S E D" Police Truetype \\\  Tous droits r�serv�s 2005 reticula.net - Vincent Wicky
  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

  ____________________________________________________________________________________

++L'usage de cette police est GRATUIT pour une utilisation personnelle et/ou non-commerciale.
  Toutefois j'acccepte volontiers les dons : www.reticula.net ! Merci de bien vouloir �galement 
  m'envoyer vos cr�ations ;) (quel que soit le support). 

++L'usage de cette police est INTERDIT pour une utilisation professionnel et/ou commercial sans
  un petit don. (voir ci-dessous comment me contacter pour les d�tails).

++Vous n'�tes pas autoris� � distribuer cette police sans ma permission. Contactez-moi pour les d�tails.

++Interdiction absolue de modifier, revendre ou inclure la police sur un CD.

  ___________________________________________________________________________________
  E-mail: contact@reticula.net                           WWW: http://www.reticula.net  




//All trademarks are property of their respective owners.//